import os
import sys

print("ITK - ACDC")
print("Ground Truth")
cmd = "testACDC.bat itk-inc-dep.rsf itk-gt.rsf"
os.system(cmd)

print()

for i in range(1,13):

    filename = "output" + str(i) + ".txt"
    filename_rsf = "output" + str(i) + ".rsf"
    filenames = ["itk-inc-dep.rsf",filename]

    with open(filename_rsf, 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                for line in infile:
                    outfile.write(line)

    print("Test " + str(i))
    cmd = "testACDC.bat " + filename_rsf + " itk-gt.rsf"
    os.system(cmd)
