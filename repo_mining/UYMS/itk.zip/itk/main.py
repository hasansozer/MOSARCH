from RSFParser import *
from datetime import datetime
from pydriller import repository, Repository, ModifiedFile
from itertools import combinations

source_file_extensions = ['.c', '.cc', '.cpp', 'cxx', '.h']

def extract_module_dependencies(committed_file_list):
    for file_list in committed_file_list:
        pair_list = combinations(file_list, 2)
        for m1, m2 in pair_list:
            dsm_eval[parser.name2ID.get(m1)][parser.name2ID.get(m2)] += 1
            dsm_eval[parser.name2ID.get(m2)][parser.name2ID.get(m1)] += 1

print("parsing the dependency file...")
parser = RSFParser("itk-gt.rsf")
parser.parse_dependency_input_file("itk-inc-dep.rsf")
clustered_items = parser.clustered_items
print("# of clustered items: {}".format(parser.total_item_count))
dsm_eval = [[0 for x in range(parser.total_item_count)] for y in range(parser.total_item_count)]
names = {value : key for (key, value) in parser.name2ID.items()}

print("obtaining commits...")

repo = Repository('C:\\Users\\abdul\\Documents\\GitHub\\ITK',
                  since=datetime(2013, 11, 1, 0, 0, 0),
                  to=datetime(2014, 11, 1, 0, 0, 0),
                  only_in_branch='master',
                  only_no_merge=True,
                  only_modifications_with_file_types=source_file_extensions)

print("analyzing changed files...")
committed_files = []
count = 0

for commit in repo.traverse_commits():
    files = commit.modified_files
    changed_files = [m for m in commit.modified_files if m.change_type == m.change_type.MODIFY]
    if len(changed_files) > 1:
        changed_source_files = [s for s in changed_files if s.filename.endswith(tuple(source_file_extensions))]
        if len(changed_source_files) > 1:
            changed_clustered_source_files = [f.new_path.replace('\\','/') for f in changed_source_files if parser.isModule(f.new_path.replace('\\','/'))]
            if len(changed_clustered_source_files) > 1:
                committed_files.append(changed_clustered_source_files)
                count += 1

print("# of commits with more than one file modified: {}".format(count))

print("analyzing module dependencies...")
extract_module_dependencies(committed_files)

for limit in range(1,500):
    file = open("output{}.txt".format(limit), "w")
    count = 0
    for i in range(0, parser.total_item_count-1):
        for j in range(i+1, parser.total_item_count):
            if dsm_eval[i][j] >= limit:
                count += 1
                if not parser.depends(i,j):
                    file.write("depends {} {}\n".format(names[i], names[j]))
                    file.write("depends {} {}\n".format(names[j], names[i]))
    print("total count > {}: {}".format(limit,count))
    file.close()

print("done analyzing...")