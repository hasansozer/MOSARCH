import os
import sys


print("ITK - MGMC")
print("Ground Truth")
cmd = "testMC.bat itk-inc-dep.rsf itk-gt.rsf"
os.system(cmd)

for i in range(1,13):

    filename = "output" + str(i) + ".txt" 

    file = open("c.txt", "w")
    file.close()

    filename_rsf = "output" + str(i) + ".rsf"

    filenames = ["itk-inc-dep.rsf",filename]

    with open(filename_rsf, 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                for line in infile:
                    outfile.write(line)

    print("Test " + str(i))
    cmd = "testMC.bat " + filename_rsf + " itk-gt.rsf"
    os.system(cmd)
