class RSFParser:

    def isModule(self, module_name):
        return module_name in self.name2ID

    def depends(self, i, j):
        return self.dsm[i][j] > 0

    def dependency(self, e1, e2):
        sum = 0
        if self.dsm[self.name2ID.get(e1)][self.name2ID.get(e2)]: sum += 1
        if self.dsm[self.name2ID.get(e2)][self.name2ID.get(e1)]: sum += 1
        return sum

    def __init__(self, filename):
        self.filename = filename
        self.clustered_items = []
        self.name2ID = {}
        self.total_item_count = 0

        self.parse_clustering_input_file(filename)
        self.dsm = [[False for x in range(self.total_item_count)] for y in range(self.total_item_count)]

    def parse_clustering_input_file(self, filename):
        try:
            f = open(filename, "r+")
            cluster_name = ""
            current_cluster = ""
            item_name = ""
            cluster_count = 0

            for line in f:
                tokens = line.split()
                cluster_name = tokens[1]
                if current_cluster != cluster_name:
                    current_cluster = cluster_name
                    cluster_count += 1
                    self.clustered_items.append([])

                item_name = tokens[2]
                self.clustered_items[cluster_count - 1].append(item_name)
                self.name2ID.update({item_name: self.total_item_count})
                self.total_item_count += 1

            f.close()
        except:
            print("Error while reading an input file!111")


    def parse_dependency_input_file(self, filename):
        try:
            with open(filename) as infile:
                for line in infile:
                    tokens = line.split()
                    if(self.isModule(tokens[1]) and self.isModule(tokens[2])):
                        self.dsm[self.name2ID.get(tokens[1])][self.name2ID.get(tokens[2])] = True
        except BaseException as e:
            print(str(e))
