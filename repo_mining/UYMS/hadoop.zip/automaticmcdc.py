import os
import sys

print("HADOOP - MCDC")
print("Ground Truth - HADOOP")
cmd = "testMC.bat hadoop-inc-dep.rsf hadoop-gt.rsf"
os.system(cmd)


for i in range(1,30):

    filename = "output" + str(i) + ".txt" 

    file = open("c.txt", "w")
    file.close()

    filename_rsf = "output" + str(i) + ".rsf"

    filenames = ["hadoop-inc-dep.rsf",filename]

    with open(filename_rsf, 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                for line in infile:
                    outfile.write(line)

    print("Test " + str(i))
    cmd = "testMC.bat " + filename_rsf + " hadoop-gt.rsf"
    os.system(cmd)
